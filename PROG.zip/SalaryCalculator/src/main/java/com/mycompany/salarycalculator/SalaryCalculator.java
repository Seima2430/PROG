/*
 * Salary Calculator Program
 * Demonstrates percentage calculation and salary increase.
 */

package com.mycompany.salarycalculator;

/**
 * A simple program to calculate percentages and salary increases.
 * 
 * @author RC_Student_lab
 */
public class SalaryCalculator 
{
    // Global (static) variables for student information
    static String studentName = "Amahle";
    static String studentSurname = "Seima";

    // Instance variables for demonstration
    double salary = 1000.00;
    double percentage = 10.0 / 100.0; // Corrected: use double division
    double results = salary * percentage;
    
    public static void main(String[] args) 
    {
        System.out.println("=== Salary Calculator ===");
        
        // Call methods
        calculateSalary();
        calculateIncreasedSalary();
    }
    
    /**
     * Method to calculate a salary percentage
     */
    public static void calculateSalary()
    {
        // Local calculation: 10% of 10,000
        double baseSalary = 10000.0;
        double percentage = 10.0 / 100.0; // Correct percentage
        double result = baseSalary * percentage;
        
        System.out.println("Name       : " + studentName);
        System.out.println("Surname    : " + studentSurname);
        System.out.println("Calculated : R" + result); // 10% of 10,000 = 1000
    }
    
    /**
     * Method to calculate salary after a 25% increase
     */
    public static void calculateIncreasedSalary()
    {
        // Local variables
        double salary = 1000.00;
        double increasePercentage = 0.25; // 25% increase
        double increasedAmount = salary * increasePercentage;
        double newSalary = salary + increasedAmount;
        
        System.out.println("\n--- Salary Increase ---");
        System.out.println("Old Salary              : R" + salary);
        System.out.println("Salary Increase Amount  : R" + increasedAmount);
        System.out.println("New Salary              : R" + newSalary);
    }
}
