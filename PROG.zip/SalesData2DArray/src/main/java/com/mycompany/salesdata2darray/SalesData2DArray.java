/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salesdata2darray;

/**
 *
 * @author RC_Student_lab
 */
public class SalesData2DArray 
{

    public static void main(String[] args) 
    {
        System.out.println("Sales Data 2D Array");
        
        // Greeting and header
        System.out.println("Hello Seima");
        System.out.println("--- Sales Data ---");
        
        // Step 1: Define number of weeks and products
        int weeks = 4;
        int products = 3;
        
        // Step 2: Declare and initialize a 2D array of sales
        // Rows = weeks, Columns = products
        int [][] sales = 
        {
            {30, 25, 40},  // Week 1 sales for 3 products
            {35, 28, 42},  // Week 2
            {32, 30, 30},  // Week 3
            {40, 34, 45}   // Week 4
        };
        
        // Step 3: Display weekly sales
        for (int i = 0; i < weeks; i++)
        {
            System.out.println("Week " + (i + 1) + ":");
            
            for (int j = 0; j < products; j++)
            {
                System.out.println("  Product " + (j + 1) + ": " + sales[i][j]);
            }
            System.out.println();
        }
        
        // Step 4: Calculate total sales for each product across all weeks
        int[] total = new int[products];
        
        for (int j = 0; j < products; j++)
        {
            for (int i = 0; i < weeks; i++)
            {
                total[j] += sales[i][j];
            }
        }
        
        // Step 5: Display total sales per product
        System.out.println("--- Total Sales per Product ---");
        for (int j = 0; j < products; j++)
        {
            System.out.println("Product " + (j + 1) + ": " + total[j]);
        }
    }
}
