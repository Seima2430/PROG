/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.scanneradditiondemo;

import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class ScannerAdditionDemo 
{
    // Global variables
    static int num1 = 200;
    static int num2 = 250;
    static int total; 
    
    public static void main(String[] args) 
    {
        System.out.println("=== Scanner Addition Demo ===");
        
        // Step 1: Create a Scanner object to read input
        Scanner myScanner = new Scanner(System.in);
        
        // Step 2: Get the user's name
        System.out.print("Please enter your name: ");
        String name = myScanner.nextLine();
        
        // Step 3: Display greeting
        System.out.println("Hi " + name);
        
        // Step 4: Call the add method
        add(num1, num2);
    } 
    
    /**
     * Method to add two numbers and display the total
     * @param firstValue first number
     * @param secondValue second number
     */
    public static void add(int firstValue, int secondValue)
    {
        total = firstValue + secondValue;
        System.out.println("Hi, your total is: " + total);
    }
}
